from setuptools import setup

setup(
	name='taxbracket',
	version='1.0',
	description='My Tax Search Tool',
	author='Henny',
	author_email='henningstonbio@gmail.com',
	url='NA',
	py_modules=['taxbracket'],
)